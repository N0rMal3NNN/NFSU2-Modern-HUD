NEW v0.10.7: RX-7 — 4 икони 2+2 околу RPM бројчаникот (TYRES/ENGINE лево, SUSP/рачна десно), синхронизирани редови, +10%; бројки повеќе не лежат врз цртички (сите скинови); GT-R и Corolla — лампичка наместо текстовите TYRES/ENGINE/SUSP/HAND. Види CHANGELOG-v0.10.7.txt.
NEW v0.10.6: RX-7 — иконите (со рачната) повеќе не влегуваат во круговите: распоред во облик на T меѓу бројчаниците (TYRES | ENGINE | SUSP горе, рачна под ENGINE); важи за Chrome и Firefox. Другите ХУД-ови се измерени — само RX-7 се преклопуваше. Детали: CHANGELOG-v0.10.6.txt
NEW v0.10.5: Mozilla/Firefox поправка — поместените ознаки GEAR/ODO и ситните бројки на бројчаниците (Firefox ја применува CSP на страницата врз inline стилови); 31 innerHTML предупредување + манифест предупредувањето се отстранети. Chrome/Chromium изгледа исто како пред. Детали: CHANGELOG-v0.10.5.txt
NEW v0.10.4: Vignette (затемнување на аглите) сега работи при возење — рампа 0% на 190 km/h до целиот поставен % на 250 km/h, и се намалува назад кога брзината паѓа; независно од главниот HUD. Види CHANGELOG-v0.10.4.txt.
NEW v0.10.3: Рачна (Space) како 4-та икона во сите брзинометри + Standalone HUD — иконата стои, свети само сијаличката додека држиш Space (во игра, не пауза); Modern HUD е повисок за повеќе место; опција Show -> Handbrake. Види CHANGELOG-v0.10.3.txt.
NEW v0.10.2: Pedals HUD "Under the speedometer" сега е навистина ПОД брзинометарот (HUD-от се подига колку што треба кога е долу на екранот). Види CHANGELOG-v0.10.2.txt.
NEW v0.10.1: Pedals HUD (гас/сопирачка: 3 места, X/Y, големина, H/V, бои), Vignette 0–100% (20% стандардно) во Speed Sensation, поправен HUD Shake (лесни удари + Standalone + Pedals + причина кога е блокиран). Види CHANGELOG-v0.10.1.txt.
NEW v0.10.0: Colors & Materials — боја на стрелки, бројки, ODO, рамки (+материјал), background (+материјал) за секој скин; Evo/STi и Supra/RX-8 икони +5% и светилки +10%; Supra/RX-8 Turbo спуштен. Види CHANGELOG-v0.10.0.txt.
NEW v0.9.99: Standalone HUD има Layout Horizontal / Vertical + нов скин Toyota Supra / Mazda RX-8 (RX-8 со дигитална брзина, NITRO како блокови). Види CHANGELOG-v0.9.99.txt.
NEW v0.9.98: Evo VIII / WRX STi — STi 30% помалку сино, поголем ODO и поголеми TYRES/ENGINE/SUSP икони. Види CHANGELOG-v0.9.98.txt.
NEW v0.9.97: нов скин Mitsubishi Lancer Evo VIII + Subaru Impreza WRX STi (Evo = бело/црвено, STi = сино/златно; автоматски по возило) + Civic: ODO и 'Civic' спуштени подолу. Види CHANGELOG-v0.9.97.txt.
NEW v0.9.96: Honda Civic преправен според EP3 — кремави бројчаници, 3 круга, црни стрелки со црвена линија, 'Civic' наместо SiR, VTEC светилка во тахометарот, нова рамка што ги следи кружниците. Види CHANGELOG-v0.9.96.txt.
NEW v0.9.95: shift-now светилките се секогаш зелени (сите скинови); Audi ODO/GEAR LCD поместени подолу, подалеку од 0 и 400. Види CHANGELOG-v0.9.95.txt.
NEW v0.9.94: нов Nissan скин за 350Z + Infiniti G35 (заеднички; 350Z = четкан алуминиум/портокалово, G35 = карбон/килибарно; автоматски бадж по возило). Види CHANGELOG-v0.9.94.txt.
NEW v0.9.93: Audi A3/TT — само подобрен текст (поголеми и посветли броеви/натписи, GEAR и ODO LCD). Види CHANGELOG-v0.9.93.txt.
NEW v0.9.92: Audi брзинометар 0–400 km/h (0–250 mph) како кај сите други возила; A3 стрелките се позаоблени (TT остануваат остри). Види CHANGELOG-v0.9.92.txt.
NEW v0.9.91: нов Audi скин за Audi A3 3.2 quattro + Audi TT (заеднички дизајн; TT = четкан прстен + остри стрелки, A3 = хромиран прстен + заоблени стрелки; автоматски бадж по возило). Види CHANGELOG-v0.9.91.txt.
NEW v0.9.90: Corolla — SHIFT текстот е тргнат, светилките се центрирани меѓу 0 и 10; нови default: Glass 50%, Standalone panel size 55%, Standalone background opacity 80%. Види CHANGELOG-v0.9.90.txt.
NEW v0.9.89: иста покриеност на стрелките во сите аналогни скинови + ODO roll (одоздола нагоре) во сите скинови. Види CHANGELOG-v0.9.89.txt.
NEW v0.9.88: поголеми TYRES/ENGINE/SUSP икони во сите скинови, GT-R рамка (опција Housing), заедничко стакло (Glass) за GT-R/Corolla/RX-7/Civic. Види CHANGELOG-v0.9.88.txt.
NEW v0.9.87: Civic Si стакло (рефлексија, гребнатини, прашина) со лизгач 'Glass'. Види CHANGELOG-v0.9.87.txt.
NEW v0.9.86: Civic Si TYRES/ENGINE/SUSP иконите се многу поголеми и се на безбедна позиција горе десно. Види CHANGELOG-v0.9.86.txt.
NEW v0.9.85: Honda Civic Si premium redesign. Види CHANGELOG-v0.9.85.txt.

NEW v0.9.62: Mazda RX-7 FD four-gauge rotary-inspired carbon HUD. Choose Mazda RX-7 in ODO or HUD Style.
RX7_SPEED uses KM/H by default, optionally MPH through Speedometer menu — only one unit shown.
Preserve your existing extension folder/ID to keep local mileage and settings.

NFSU2 Modern HUD v0.9.56 — CIV_BG v2 Carbon Contrast Fix

NFSU2 Modern HUD v0.9.55 — CIV_BG v2 carbon-fiber

v0.9.54 — Compact Civic Si case, re-spaced dials, bigger warnings, smaller ODO and independent HUD Scale (10-500%).
УНИВЕРЗАЛНО: HUD Settings > Position/Size/Transparency > HUD Scale slider + Custom HUD scale (%) number.
Civic Si користи твоите X/Y и Size позиции од Current_Settings JSON; рамката ги следи круговите.
Warning icons се без дополнителен квадратен панел; светкаат само малите квадратчиња.

NEW v0.9.47 — Honda Civic Si: owner layout & adaptive chassis

Use folder NFSU2-HUD-Chromium for Chrome/Edge/Brave/Opera; folder NFSU2-HUD-Firefox for Firefox.
Keep the same unpacked extension folder and Reload to preserve extension storage / ODO.

Civic Si now uses the X/Y and sizes exported in NFSU2-HUD-Current_Settings(1).json. The connected black background dynamically follows the gauges, without the three upper LED dots or a separate rectangular warning panel. TYRES / ENGINE / SUSP remain inside the main chassis.
See CHANGELOG-v0.9.47.txt.
NEW v0.9.45 — Honda Civic Si (EM1) HUD & Corolla status lamp fix
- Honda Civic -> dedicated Civic Si cluster, rolling ODO, frame controls.
- Corolla: only square lamp flashes, static warning icons.
- Speed digits depth option only in Modern HUD.
See CHANGELOG-v0.9.45.txt for full details.

NFSU2 MODERN HUD v0.9.44 — Custom Keyboard Shortcuts / TKL

To change keys WITHOUT a Numpad, click the extension icon in your browser and use its Keyboard Shortcuts editor.
Original defaults: Numpad + (menu), Numpad - (toggle HUD), Numpad * (SAVE ALL).
TKL backup: Ctrl + Alt + M opens the in-game settings menu.
In-game settings has the same shortcuts editor with independent Change buttons and Reset Shortcuts to Defaults.
Shortcuts auto-save and are included in exported current settings JSON. ODO mileage is not included in JSON exports.
IMPORTANT: Use the SAME extension install directory/ID while updating to preserve local ODO and settings. Do not remove the installed extension before replacing files.

NFSU2 MODERN HUD v0.9.43 — CAR SELECTION -> HUD + ODO / COROLLA FRAME CONTROL

НОВО v0.9.43:
- Redline (црвен лак) е отстранет од KM/H/MPH мерачот кај GT-R Analog и Corolla Retro.
- RPM Redline и Turbo PSI црвената зона остануваат непроменети.

* Избор на модел во ODO Car List автоматски ги вчитува HUD стилот и неговата зачувана километража.
  Nissan Skyline GT-R -> GT-R Analog. Toyota Corolla -> Corolla Retro. Сите други модели -> Modern HUD.
* HUD Style може рачно да се смени без менување на моделот или ODO. 
* Assign current HUD to car / Reset car's HUD: опционална трајна врска на стил за секој модел.
* За Corolla: Whole Frame Scale 50-175%, Whole Frame X/Y; сите инструменти, позадината, статусите,
  ODO и NITRO се движат заедно. Локалните XY позиции се ограничени и внатрешната содржина е
  исечена според рамката. GT-R позициите и големините остануваат независни.
* SAVE ALL / Numpad * ги зачувува рамката, индивидуалните XYZ големини/позиции, HUD врските и ODO.
  Settings JSON извезува/увезува рамка и HUD врски, но НЕ и ODO.
* За да остане километражата, замени ги фајловите во ИСТАТА папка на веќе инсталираната екстензија
  и направи Reload. Нова инсталација со различен Extension ID не ги гледа старите километражи.

--- PREVIOUS VERSION NOTES ---

NFSU2 MODERN HUD v0.9.38 — ODOMETER BY CAR + NUMPAD * SAVE

NEW v0.9.38:
* TYRES, ENGINE and SUSP indicators moved to the three locations marked in the screenshot (above/around the speed-dial hub).
* ODO LCD in GT-R Analog remains below gear; Modern HUD has its ODO directly below speed digits, above SHIFT.
* Open the independent Odometer — Mileage by Car menu fieldset to choose 1 of 31 vehicles. Mileage is separate for every chosen car model.
* The Numpad * key is SAVE ALL: it stores both all current HUD settings AND all car-mileage totals without opening the menu.
* 00000032.1 means 32.1 km; decimal digit represents 100 m. Maximum displayable mileage is 9,999,999.9 km.
* It starts from 0.0 km and counts only while the Car Feed shows driving; it is NOT the actual in-game car odometer.
* Automatic ODO checkpoints at each 100 m, every 30 seconds while driving (when changed), and when leaving a tab/drive session.
* HUD menu buttons: Save mileage now and Reset selected car (confirmation needed). The reset affects only the chosen vehicle. Save current settings now also saves all mileage.
* Because NFSU2.xyz's native game Save does not expose a stable public signal through Car Feed, ODO saves are independent from the native game save, and remain local to this browser/extension. Native cloud save does not include ODO.
* GT-R Analog Customization: needle color, dial numbers, tick color, numeric illumination slider and optional subtle depth.
* Default dial colors, positions, sizes and layout outside the three indicator positions remain unchanged.
* Settings menu can be resized but slider, text and swatch column stays the original max width; controls no longer stretch.
* Car ODO totals are NOT included in JSON settings profiles and are not reset when you reset HUD defaults.
* Upgrades from v0.9.27 keep the former single mileage under Previous ODO (unassigned). You can change to an actual model using the dropdown.
* The selected model is manual, not read from the game. Two owned cars of the same model share one mileage counter; separate same-model copies are not tracked.
* Switching models takes effect immediately and resets the time integration so no distance is counted for the wrong car.
* Other features (Impact, Speed Sensation, Fog, 400 km/h, collision balance, Limp Mode) are unchanged.

PREVIOUS v0.9.24:
* TYRES icon: restores the wheel/tire-with-tread symbol previously used in Modern HUD. Analog now uses the same wheel symbol.
* Analog TYRES and SUSP label text placed only 3 SVG pixels lower; ENGINE icon/label unchanged.
* Blue Fog now has independent adjustable opacity (0–100%, default 12%) alongside the existing Enable Blue Fog toggle.
* 12% preserves the previous fog appearance at all four edges. Changing the opacity does not change Speed Sensation intensity or animation.
* User's saved settings are preserved. Blue Fog opacity is saved and included in JSON profiles.
* No changed dial geometry, collision physics or other HUD visuals.

NEW v0.9.23:
* TYRES: original Car Traction / Slip dashboard SVG.
* ENGINE: original Check Engine dashboard SVG.
* SUSP: original shock absorber with spring dashboard SVG.
* Both Modern Digital HUD and GT-R Analog HUD have matching new icons.
* Original icon sizes, label positions, warning states, analog positions and telemetry behavior retained.
* All changes from v0.9.22 retained, no settings migration needed.

NFSU2 MODERN HUD v0.9.23 — DASHBOARD WARNING ICON REDESIGN

NEW / FIXES:
* Minimum collision speed default = 130 km/h (previously 150).
* SUSP (coilover / suspension) impact events processed on EVERY Car Feed message, independently from display repaint cadence.
* Severe crash telemetry fallback: rapid stop from 220 km/h to zero is detected even when the game does not send impactDv or increment impact counter. This is a conservative estimate, not the game's real collision sensor.
* Minor nudges are filtered via adjustable velocity and speed thresholds; Impact Feedback and LIMP Mode remain distinct.
* LIMP MODE Repair Timer DEFAULT = 30 seconds; separate No Impact Timer DEFAULT = 60 seconds.
* Analog Turbo / RPM / Speed circles can move across the full screen via X/Y sliders and precise pixel inputs. Original positions (Turbo 0/0, RPM 0/0, Speed +8/0), circle sizes and design unchanged.
* Reset Analog Circle Positions button resets only circle offsets.
* Saved preferences and JSON profiles, Blue Fog, GT-R 400 km/h and all previous functions preserved.
* Defaults migrated once; custom values different from older defaults preserved.

INSTALL: Extract ZIP. Choose NFSU2-HUD-Chromium for Chrome/Edge/Brave/Opera, or NFSU2-HUD-Firefox for Firefox. Replace old extension folder files, reload extension, refresh game.

Note: Inferred hard-stop events may still differ from the game's physical collisions. Verify on track.

NEW v0.9.38: Numpad * quick Save fix: success confirmed after saved snapshot is read back from browser storage; live km updates no longer cause false incomplete warning.

IMPORTANT v0.9.38: Keep the SAME installed extension folder (not a newly unpacked folder path) when upgrading, so the browser keeps the same extension ID and its mileage storage. If an older installation has a different extension ID, the stored mileage is isolated to that old installation and cannot be automatically moved.


v0.9.38: Нов Toyota Corolla Retro HUD; 400 km/h, динамична RPM скала од Car Feed, автоматска ODO врска за GT-R/Corolla при избор на стил и рачно менување без губење километража; поправен HUD Shake на самиот брзинометар.

Corolla Retro 1986 v0.9.38: единствена ретро табла со три инструменти, ретро текстура, посебни предупредувања, долна нитро лента.

Corolla v0.9.38: статус ламбите TYRES/ENGINE/SUSP се по едно сиво поле (жолто/црвено на предупредување), панелот е меѓу RPM и SPEED, Nitro не го преклопува брзинометарот, ретро ознаките се појасни.

NOVO v0.9.38: Во Settings > Analog / Corolla — Circle Size & Position можеш посебно да ги зголемиш/намалиш Turbo, RPM и Speed (50–160%). X/Y позициите остануваат рачно прилагодливи. Притисни SAVE ALL — HUD, sizes, positions & ODO и провери потврда дека се зачувани.

NOVO v0.9.38: Во Settings > Analog / Corolla — Circle Size & Position можеш посебно да ги зголемиш/намалиш Turbo, RPM и Speed (50–160%). X/Y позициите остануваат рачно прилагодливи. Притисни SAVE ALL — HUD, sizes, positions & ODO и провери потврда дека се зачувани.


v0.9.39: Corolla default positions and 85% scale; separated GT-R/Corolla positions; full X/Y + sizes exported in JSON.

v0.9.40 — Corolla background now follows each dial X/Y + size, full layouts saved and exported in JSON.
