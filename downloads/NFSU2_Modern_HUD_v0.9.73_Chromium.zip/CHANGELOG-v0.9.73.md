# NFSU2.xyz Modern HUD — v0.9.73

## Layout/defaults refinement (2026-11-22)
- **Honda Civic Si**: adopted the owner's final X/Y arrangement as the ZERO-offset starting point: Nitro/Turbo 13/15 at 85%, RPM 12/10 at 95%, Speed 18/22 at 95%. The default Civic HUD scale is 60%.
- **GT-R Analog, Toyota Corolla, RX-7**: factory X/Y position controls now start and reset at 0 px. The approved physical gauge placements are baked into the rendering geometry.
- Added migration of active settings and saved custom profiles to schema 4; existing visible positions are preserved when updating from v0.9.72 and older. JSON imports with legacy coordinates are converted once. New JSON exports carry the `zero-v0973` origin marker.
- Odometer data remains in its separate existing V3 storage; migrations do not reset mileage.

## Other development highlights from today's HUD iterations
- Honda Civic Si: carbon analog dashboard with ivory/white dials, a combined two-needle Nitro/Turbo gauge, simulated VTEC at 5,600 RPM, gear/shift lighting, and warning lamps.
- Mazda RX-7 FD: dedicated dark carbon rotary-style analog cluster, separate Turbo/Nitro dials, single selectable KM/H or MPH speed scale, green shift guidance, and repositionable gauges.
- Toyota Corolla Retro: instrument/bezel refinements, visible GEAR roll and smooth mechanical ODO digit rolls.
- Honda Civic Si: smoother ODO digit rolls with independent changing wheels and layout refinements.
- Modern HUD: RPM upper-label clearance fix; GT-R / Corolla gear roll animation maintained.
- Individual HUD scale, precise circle X/Y and size controls, per-vehicle ODO storage, and cross-browser packaging retained.

## Compatibility and verification
- Chrome / Edge / Brave / Opera: load `NFSU2-HUD-Chromium` as an unpacked extension.
- Chromium: use the included `NFSU2-HUD-Chromium` package according to its README.
- Verified with Chromium simulated telemetry and the owner's old JSON settings. Visual coordinates match the pre-update positions for each legacy analog skin.
- **Not yet tested live in NFSU2.xyz with v0.9.73.** User approval is required before any GitHub publication.
